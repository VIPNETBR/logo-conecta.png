#!/bin/bash
cd "$(dirname "$0")"
python3 multi_scraper.py >> log.txt 2>&1
