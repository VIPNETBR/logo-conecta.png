📦 TELEGRAM SCRAPER – Sistema Avanzado Automatizado

✅ Requisitos:
- Ubuntu 20/22/24
- Python 3.8+
- Conexión a internet

🔧 Instalación:
1. Subir el archivo telegram-scraper.zip al VPS
2. Descomprimir:
   unzip telegram-scraper.zip && cd telegram-scraper
3. Ejecutar el instalador:
   bash install.sh
4. Ejecutar el panel:
   bash menu

📂 Archivos:
- install.sh: Instalador automático
- menu: Panel de administración
- multi_scraper.py: Script principal (extrae + agrega)
- cuentas.yaml: Configurar cuentas Telegram
- grupos.yaml: Grupos de origen y destino
- cron_launcher.sh: Script diario automático
- log.txt: Registro de ejecución
