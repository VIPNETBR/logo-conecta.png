import os
import csv
import asyncio
from pyrogram import Client
from telethon import utils
from pyrogram.errors import (
    UserPrivacyRestricted,
    PeerFlood,
    UserChannelsTooMuch,
    UserBannedInChannel,
    FloodWait,
    RPCError,
    UserAlreadyParticipant,
)

api_id = 23269382
api_hash = "fe19c565fb4378bd5128885428ff8e26"

SESSIONS_DIR = "sessions"
PHONES_CSV = "phone.csv"

async def add_members():
    target_group = input("Ingrese el usuario público o enlace del grupo a extraer miembros: ").strip()
    my_group = input("Ingrese el usuario público o enlace de su grupo para agregar miembros: ").strip()
    delay = int(input("Ingrese el tiempo de espera (segundos) entre cada solicitud (0 para ninguno): "))
    max_add = int(input("Ingrese la cantidad máxima de miembros a agregar por cuenta (máximo 50): "))

    # Leer cuentas autorizadas
    if not os.path.exists(PHONES_CSV):
        print("No se encontró el archivo de cuentas (phone.csv). Agrega cuentas primero.")
        return

    with open(PHONES_CSV, "r") as f:
        phones = [row[0] for row in csv.reader(f)]

    existing_members = set()
    added_members = set()

    # Usar la primera cuenta para obtener miembros existentes en su grupo destino
    first_phone_clean = "".join(filter(str.isdigit, phones[0]))
    async with Client(session_name=os.path.join(SESSIONS_DIR, first_phone_clean),
                      api_id=api_id, api_hash=api_hash) as app:
        try:
            await app.join_chat(my_group)
            my_group_entity = await app.get_chat(my_group)
            async for member in app.get_chat_members(my_group_entity.id):
                existing_members.add(member.user.id)
        except Exception as e:
            print(f"Error accediendo a tu grupo: {e}")
            return

    print(f"Miembros existentes en tu grupo: {len(existing_members)}")

    # Añadir miembros
    for phone in phones:
        phone_clean = "".join(filter(str.isdigit, phone))
        async with Client(session_name=os.path.join(SESSIONS_DIR, phone_clean),
                          api_id=api_id, api_hash=api_hash) as app:
            print(f"Iniciando sesión con {phone}...")
            try:
                await app.join_chat(target_group)
                await app.join_chat(my_group)
                target_entity = await app.get_chat(target_group)
                count_added = 0

                async for member in app.get_chat_members(target_entity.id):
                    if member.user.id not in existing_members and member.user.id not in added_members:
                        try:
                            await app.add_chat_members(my_group_entity.id, member.user.id)
                            print(f"Agregado usuario {member.user.first_name} ({member.user.id})")
                            added_members.add(member.user.id)
                            count_added += 1
                            if count_added >= max_add:
                                print(f"Se agregó el máximo ({max_add}) de miembros para esta cuenta.")
                                break
                            if delay > 0:
                                await asyncio.sleep(delay)
                        except UserPrivacyRestricted:
                            print("Privacidad restringe agregar este usuario, saltando...")
                        except UserAlreadyParticipant:
                            print("Usuario ya es participante, saltando...")
                        except PeerFlood:
                            print("PeerFlood detectado, deteniendo para esta cuenta.")
                            break
                        except UserChannelsTooMuch:
                            print("Cuenta ha alcanzado límite de canales, saltando...")
                            break
                        except UserBannedInChannel:
                            print("Cuenta baneada en el canal, saltando...")
                            break
                        except FloodWait as e:
                            print(f"FloodWait: esperando {e.x} segundos")
                            await asyncio.sleep(e.x)
                        except RPCError as e:
                            print(f"RPCError: {e}")
            except Exception as e:
                print(f"Error con la cuenta {phone}: {e}")

if __name__ == "__main__":
    asyncio.run(add_members())