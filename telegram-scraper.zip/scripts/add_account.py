from telethon.sync import TelegramClient
from telethon.sessions import StringSession
from telethon.errors import SessionPasswordNeededError

def agregar_cuenta():
    api_id = 14867530
    api_hash = "45be4550cf972bfc274541b00fdf76a1"
    phone = input("📱 Ingresa tu número (ej: +595...): ")
    with TelegramClient(StringSession(), api_id, api_hash) as client:
        client.send_code_request(phone)
        code = input("📨 Ingresa el código recibido: ")
        try:
            client.sign_in(phone, code)
        except SessionPasswordNeededError:
            password = input("🔐 Ingresa tu contraseña 2FA: ")
            client.sign_in(password=password)
        string = client.session.save()
        with open("cuentas.yaml", "a") as f:
            f.write(f"{string}\n")
        print("✅ Cuenta añadida correctamente.")
