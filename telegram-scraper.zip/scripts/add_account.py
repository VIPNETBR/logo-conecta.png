from telethon.sync import TelegramClient
from telethon.sessions import StringSession
from telethon.errors import SessionPasswordNeededError

API_ID = 14867530
API_HASH = "45be4550cf972bfc274541b00fdf76a1"

def agregar_cuenta():
    phone = input("📱 Ingresa tu número (ej: +595...): ").strip()
    with TelegramClient(StringSession(), API_ID, API_HASH) as client:
        client.send_code_request(phone)
        code = input("📨 Ingresa el código recibido: ").strip()
        try:
            client.sign_in(phone, code)
        except SessionPasswordNeededError:
            password = input("🔐 Ingresa tu contraseña 2FA: ").strip()
            client.sign_in(password=password)
        string = client.session.save()
    with open("cuentas.yaml", "a") as f:
        f.write(f"{string}\n")
    print("✅ Cuenta añadida correctamente.")