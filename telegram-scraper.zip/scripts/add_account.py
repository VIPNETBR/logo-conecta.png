import csv
import os
from pyrogram import Client
from pyrogram.errors import AuthKeyUnregistered, SessionExpired, SessionRevoked, UserDeactivatedBan, UserDeactivated
from telethon import utils
from colorama import Fore, Style, init

init(autoreset=True)

api_id = '23269382'   # Cambia si tienes otro API ID
api_hash = 'fe19c565fb4378bd5128885428ff8e26'  # Cambia si tienes otro API HASH

PHONE_CSV = 'phone.csv'

def remove_blank_lines(filename):
    if not os.path.exists(filename):
        return
    with open(filename, 'r') as f:
        lines = f.readlines()
    with open(filename, 'w') as f:
        f.writelines(line for line in lines if line.strip())

def remove_duplicates(lst):
    return list(set(lst))

def login():
    if not os.path.exists(PHONE_CSV):
        open(PHONE_CSV, 'w').close()

    remove_blank_lines(PHONE_CSV)

    num_accounts = int(input("Ingrese la cantidad de cuentas a agregar: "))
    new_phones = []
    for i in range(num_accounts):
        phone = input(f"Ingrese número de teléfono {i+1} (con código país, ej +595...): ").strip()
        new_phones.append(phone)

    # Leer teléfonos ya registrados
    existing_phones = []
    if os.path.exists(PHONE_CSV):
        with open(PHONE_CSV, 'r') as f:
            existing_phones = [row[0] for row in csv.reader(f)]

    phones_to_add = [p for p in remove_duplicates(new_phones) if p not in existing_phones]

    if not phones_to_add:
        print(Fore.YELLOW + "No hay cuentas nuevas para agregar.")
        return

    with open(PHONE_CSV, 'a', newline='') as csvfile:
        writer = csv.writer(csvfile)
        for phone in phones_to_add:
            try:
                print(f"Intentando login: {phone}")
                app = Client(f"sessions/{phone.replace('+','')}", api_id, api_hash, phone_number=phone)
                app.start()
                print(Fore.GREEN + f"Login exitoso para {phone}")
                app.stop()
                writer.writerow([phone])
            except Exception as e:
                print(Fore.RED + f"Error al loguear {phone}: {e}")

    print(Style.RESET_ALL + "Proceso terminado.")


if __name__ == "__main__":
    login()