from telethon.sync import TelegramClient
from telethon.sessions import StringSession
from telethon.errors import SessionPasswordNeededError, PhoneNumberBannedError, PhoneNumberFloodError
import yaml
import os

CONFIG_FILE = "cuentas.yaml"

def cargar_cuentas():
    if os.path.exists(CONFIG_FILE):
        with open(CONFIG_FILE, "r") as f:
            return yaml.safe_load(f) or []
    return []

def guardar_cuentas(cuentas):
    with open(CONFIG_FILE, "w") as f:
        yaml.dump(cuentas, f)

def agregar_cuenta():
    api_id = 23269382  # Tu api_id
    api_hash = "fe19c565fb4378bd5128885428ff8e26"  # Tu api_hash

    cuentas = cargar_cuentas()

    while True:
        phone = input("📱 Ingresa tu número (ej: +595...): ").strip()
        try:
            with TelegramClient(StringSession(), api_id, api_hash) as client:
                print(f"Enviando código a {phone}...")
                client.send_code_request(phone, force_sms=True)  # Forzar SMS si falla

                code = input("📨 Ingresa el código recibido: ").strip()
                try:
                    client.sign_in(phone, code)
                except SessionPasswordNeededError:
                    password = input("🔐 Ingresa tu contraseña 2FA: ").strip()
                    client.sign_in(password=password)

                session_str = client.session.save()
                cuentas.append(session_str)
                guardar_cuentas(cuentas)
                print("✅ Cuenta añadida correctamente.")
        except PhoneNumberBannedError:
            print("❌ El número está baneado por Telegram. Usa otro número.")
        except PhoneNumberFloodError:
            print("❌ Has enviado muchas solicitudes de código. Intenta más tarde.")
        except Exception as e:
            print(f"❌ Error: {e}")

        mas = input("¿Quieres agregar otra cuenta? (s/n): ").lower()
        if mas != 's':
            break