import os
import csv
from pyrogram import Client

# Configuración de API (usa tus datos reales)
api_id = 23269382
api_hash = "fe19c565fb4378bd5128885428ff8e26"

SESSIONS_DIR = "sessions"
PHONES_CSV = "phone.csv"

if not os.path.exists(SESSIONS_DIR):
    os.mkdir(SESSIONS_DIR)

def save_phone(phone):
    # Guarda número en phone.csv si no está duplicado
    if not os.path.exists(PHONES_CSV):
        with open(PHONES_CSV, "w", newline="") as f:
            pass
    with open(PHONES_CSV, "r", newline="") as f:
        existing = [row[0] for row in csv.reader(f)]
    if phone not in existing:
        with open(PHONES_CSV, "a", newline="") as f:
            writer = csv.writer(f)
            writer.writerow([phone])

def main():
    try:
        cantidad = int(input("Ingrese la cantidad de cuentas a agregar: "))
    except ValueError:
        print("Debe ingresar un número válido.")
        return

    for i in range(cantidad):
        phone = input(f"Ingrese número de teléfono {i+1} (con código país, ej +595...): ").strip()

        # Limpieza del número para usar en nombre de sesión
        phone_clean = "".join(filter(str.isdigit, phone))

        print(f"Intentando login: {phone}")

        try:
            app = Client(
                session_name=os.path.join(SESSIONS_DIR, phone_clean),
                api_id=api_id,
                api_hash=api_hash,
                phone_number=phone,
                workdir=SESSIONS_DIR,
            )

            app.connect()
            if not app.is_user_authorized():
                app.send_code_request(phone)
                code = input(f"Ingrese el código enviado a {phone}: ")
                app.sign_in(phone, code)

            print(f"Login exitoso: {phone}")
            save_phone(phone)
            app.disconnect()

        except Exception as e:
            print(f"Error al loguear {phone}: {e}")

    print("Proceso terminado.")
    input("Presione Enter para continuar...")

if __name__ == "__main__":
    main()