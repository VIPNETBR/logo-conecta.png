from telethon.sync import TelegramClient
from telethon.sessions import StringSession
import yaml
import os

CONFIG_FILE = "config.yaml"

def cargar_config():
    if os.path.exists(CONFIG_FILE):
        with open(CONFIG_FILE, "r") as f:
            return yaml.safe_load(f) or {}
    return {}

def guardar_config(config):
    with open(CONFIG_FILE, "w") as f:
        yaml.dump(config, f)

def agregar_cuenta():
    print("--- Agregar Cuenta Telegram ---")
    api_id = int(input("🔢 Ingresa tu API ID de Telegram: "))
    api_hash = input("🔐 Ingresa tu API Hash de Telegram: ")
    numero = input("📱 Ingresa tu número de teléfono (ej: +595...): ").strip()

    print("📤 Enviando código de verificación...")
    client = TelegramClient(StringSession(), api_id, api_hash)

    with client:
        try:
            client.send_code_request(numero)
            codigo = input("✅ Ingresa el código recibido (ej: 12345): ")
            try:
                client.sign_in(numero, codigo)
            except Exception as e:
                if "2FA" in str(e):
                    password = input("🔒 Tu cuenta tiene verificación en 2 pasos. Ingresa tu contraseña: ")
                    client.sign_in(password=password)
        except Exception as e:
            print("❌ Error durante el inicio de sesión:", e)
            return

        session_string = client.session.save()
        print("✅ Cuenta añadida con éxito.")

    # Guardar en config.yaml
    config = cargar_config()
    cuentas = config.get("cuentas", [])
    cuentas.append({
        "api_id": api_id,
        "api_hash": api_hash,
        "numero": numero,
        "session_string": session_string
    })
    config["cuentas"] = cuentas
    guardar_config(config)
    input("Presiona Enter para volver al menú...")
