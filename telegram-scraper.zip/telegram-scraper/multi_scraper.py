import yaml
import os
from telethon import TelegramClient, errors
import asyncio
import logging

logging.basicConfig(filename='log.txt', level=logging.INFO, format='%(asctime)s %(message)s')

CONFIG_FILE = 'config.yaml'
ACCOUNTS_FILE = 'accounts.yaml'

async def add_members(client, source_group, target_group):
    try:
        async for user in client.iter_participants(source_group):
            try:
                await client(InviteToChannelRequest(target_group, [user]))
                logging.info(f"Agregado {user.id} - {user.username}")
            except errors.UserPrivacyRestrictedError:
                logging.warning(f"No se pudo agregar a {user.id} - privacidad restringida")
            except Exception as e:
                logging.error(f"Error agregando {user.id}: {e}")
    except Exception as e:
        logging.error(f"Error iterando participantes: {e}")

async def main():
    if not os.path.exists(CONFIG_FILE):
        print("Archivo de configuración no encontrado.")
        return

    with open(CONFIG_FILE, 'r') as f:
        config = yaml.safe_load(f)

    with open(ACCOUNTS_FILE, 'r') as f:
        accounts = yaml.safe_load(f)

    for account in accounts['accounts']:
        print(f"Iniciando sesión con {account['phone']}")
        client = TelegramClient(account['session'], account['api_id'], account['api_hash'])
        await client.start(phone=account['phone'])
        source_groups = config.get('source_groups', [])
        target_group = config.get('target_group')

        for source in source_groups:
            print(f"Extrayendo miembros de {source} hacia {target_group}")
            await add_members(client, source, target_group)

        await client.disconnect()

if __name__ == '__main__':
    asyncio.run(main())