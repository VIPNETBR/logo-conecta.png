import sys
import yaml
from telethon.sync import TelegramClient
from telethon.sessions import StringSession

api_id = int(input("🔑 Ingresa tu API ID: "))
api_hash = input("🔐 Ingresa tu API Hash: ")

phone = sys.argv[1]
client = TelegramClient(StringSession(), api_id, api_hash)

client.connect()
if not client.is_user_authorized():
    client.send_code_request(phone)
    code = input("📩 Ingresa el código recibido por Telegram: ")
    client.sign_in(phone, code)

session_str = client.session.save()

try:
    with open("cuentas.yaml", "r") as f:
        cuentas = yaml.safe_load(f) or {"cuentas": []}
except FileNotFoundError:
    cuentas = {"cuentas": []}

cuentas["cuentas"].append({
    "phone": phone,
    "api_id": api_id,
    "api_hash": api_hash
})

with open("cuentas.yaml", "w") as f:
    yaml.dump(cuentas, f)

print("✅ Cuenta guardada correctamente.")
client.disconnect()
