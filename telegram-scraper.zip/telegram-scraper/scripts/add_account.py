import yaml
import os
from telethon import TelegramClient
import asyncio

ACCOUNTS_FILE = '../accounts.yaml'

async def main():
    phone = input("Número de teléfono (+código país): ")
    api_id = int(input("API ID: "))
    api_hash = input("API HASH: ")
    session_name = phone.replace('+', '')  

    client = TelegramClient(session_name, api_id, api_hash)
    await client.start(phone)

    if os.path.exists(ACCOUNTS_FILE):
        with open(ACCOUNTS_FILE, 'r') as f:
            data = yaml.safe_load(f)
    else:
        data = {'accounts': []}

    # Verificar duplicados
    for acc in data['accounts']:
        if acc['phone'] == phone:
            print("Cuenta ya existe.")
            return

    data['accounts'].append({
        'phone': phone,
        'api_id': api_id,
        'api_hash': api_hash,
        'session': session_name
    })

    with open(ACCOUNTS_FILE, 'w') as f:
        yaml.dump(data, f)

    print("Cuenta agregada con éxito.")

if __name__ == '__main__':
    asyncio.run(main())