#!/bin/bash
set -e

echo "🔄 Actualizando sistema e instalando dependencias..."
sudo apt update && sudo apt install -y python3 python3-pip git curl

echo "📦 Instalando librerías Python necesarias..."
pip3 install --upgrade telethon pyyaml

echo "✅ Instalación finalizada."