#!/bin/bash
echo "🔄 Instalando dependencias..."
sudo apt update && sudo apt install -y python3 python3-pip git curl unzip
pip3 install telethon pyyaml
echo "✅ Instalación completada."
