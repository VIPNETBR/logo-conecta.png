import os
import sys

def clear_screen():
    os.system('cls' if os.name == 'nt' else 'clear')

def pause():
    input("Presiona Enter para continuar...")

def agregar_cuenta():
    from scripts import add_account
    add_account.login()

def configurar_grupos():
    from scripts import config_groups
    config_groups.configure_groups()

def ejecutar_scraper():
    from scripts import scraper
    scraper.run_scraper()

def main():
    while True:
        clear_screen()
        print("====================================")
        print("      Telegram Scraper Menu         ")
        print("====================================")
        print("1) Agregar cuenta Telegram")
        print("2) Configurar grupos origen y destino")
        print("3) Ejecutar scraper manual")
        print("4) Salir")
        opcion = input("Seleccione una opción: ").strip()

        if opcion == "1":
            print("--- Agregar Cuenta Telegram ---")
            agregar_cuenta()
            pause()
        elif opcion == "2":
            print("--- Configurar grupos ---")
            configurar_grupos()
            pause()
        elif opcion == "3":
            print("--- Ejecutar Scraper Manual ---")
            ejecutar_scraper()
            pause()
        elif opcion == "4":
            print("Saliendo...")
            sys.exit(0)
        else:
            print("Opción inválida, intenta de nuevo.")
            pause()

if __name__ == "__main__":
    main()