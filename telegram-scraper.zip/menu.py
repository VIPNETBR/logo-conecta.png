import os
import sys

def clear_screen():
    os.system('cls' if os.name == 'nt' else 'clear')

def pause():
    input("\nPresiona Enter para continuar...")

def main_menu():
    while True:
        clear_screen()
        print("=== MENÚ PRINCIPAL ===")
        print("1. Agregar cuentas Telegram")
        print("2. Ejecutar scraper para agregar miembros")
        print("3. Salir")
        choice = input("Seleccione una opción: ")

        if choice == "1":
            os.system("python3 scripts/add_account.py")
            pause()
        elif choice == "2":
            os.system("python3 scripts/scraper.py")
            pause()
        elif choice == "3":
            print("Saliendo...")
            sys.exit(0)
        else:
            print("Opción inválida.")
            pause()

if __name__ == "__main__":
    main_menu()