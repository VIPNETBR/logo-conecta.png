#!/usr/bin/env python3
import sys
import time

def agregar_cuenta():
    print("\n--- Agregar Cuenta Telegram ---")
    # Aquí va tu código para agregar cuenta
    input("\nPresiona Enter para volver al menú...")
    menu()

def configurar_grupos():
    print("\n--- Configurar Grupos Origen y Destino ---")
    # Aquí va tu código para configurar grupos
    input("\nPresiona Enter para volver al menú...")
    menu()

def ejecutar_scraper():
    print("\n--- Ejecutar Scraper Manualmente ---")
    # Aquí va tu código para ejecutar scraper
    input("\nPresiona Enter para volver al menú...")
    menu()

def salir():
    print("Saliendo...")
    sys.exit()

def menu():
    while True:
        print("\n====================================")
        print("      Telegram Scraper Menu")
        print("====================================")
        print("1) Agregar cuenta Telegram")
        print("2) Configurar grupos origen y destino")
        print("3) Ejecutar scraper manual")
        print("4) Salir")
        opcion = input("Seleccione una opción: ").strip()
        if opcion == "1":
            agregar_cuenta()
        elif opcion == "2":
            configurar_grupos()
        elif opcion == "3":
            ejecutar_scraper()
        elif opcion == "4":
            salir()
        else:
            print("Opción inválida, intente de nuevo.")
            time.sleep(1)

if __name__ == "__main__":
    menu()