#!/usr/bin/env python3
import sys
import os
from scripts.add_account import agregar_cuenta
from manage_groups import configurar_grupos
from multi_scraper import ejecutar_scraper

def menu_interactivo():
    while True:
        os.system('clear')
        print("""
====================================
       Telegram Scraper Menu
====================================
1) Agregar cuenta Telegram
2) Agregar grupos origen y destino
3) Ejecutar scraper
4) Salir
""")
        opcion = input("Seleccione una opción: ").strip()
        if opcion == "1":
            agregar_cuenta()
        elif opcion == "2":
            configurar_grupos()
        elif opcion == "3":
            ejecutar_scraper()
            input("\nPresiona ENTER para continuar...")
        elif opcion == "4":
            print("👋 Saliendo...")
            break
        else:
            print("Opción no válida.")
            input("Presiona ENTER para continuar...")

def main():
    if len(sys.argv) > 1:
        cmd = sys.argv[1].lower()
        if cmd == "ejecutar_scraper":
            ejecutar_scraper()
        else:
            print(f"Comando no reconocido: {cmd}")
    else:
        menu_interactivo()

if __name__ == "__main__":
    main()