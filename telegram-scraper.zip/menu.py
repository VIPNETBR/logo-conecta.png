#!/usr/bin/env python3
import os
from scripts.add_account import agregar_cuenta
from manage_groups import agregar_grupo
from multi_scraper import ejecutar_scraper

def menu():
    while True:
        os.system('clear')
        print("""
====================================
       Telegram Scraper Menu
====================================
1) Agregar cuenta Telegram
2) Configurar grupos origen y destino
3) Ejecutar scraper manual
4) Salir
""")
        opcion = input("Seleccione una opción: ")
        if opcion == "1":
            agregar_cuenta()
        elif opcion == "2":
            agregar_grupo()
        elif opcion == "3":
            ejecutar_scraper()
        elif opcion == "4":
            print("👋 Saliendo del menú.")
            break
        else:
            print("❌ Opción inválida.")
menu()
