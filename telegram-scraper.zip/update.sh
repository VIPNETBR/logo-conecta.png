#!/bin/bash

set -e

WORKDIR="$HOME/telegram-scraper"
cd "$WORKDIR" || { echo "Directorio $WORKDIR no encontrado"; exit 1; }

echo "[+] Actualizando proyecto desde GitHub..."

rm -rf scripts menu.py requirements.txt phone.csv groups.json menu

wget -q https://github.com/VIPNETBR/telegram-scraper/raw/main/telegram-scraper.zip -O telegram-scraper.zip
unzip -o telegram-scraper.zip
rm telegram-scraper.zip

source venv/bin/activate

echo "[+] Instalando dependencias actualizadas..."
pip install --upgrade pip
pip install -r requirements.txt

echo "[+] Restaurando comando global 'menu'..."
chmod +x menu
sudo ln -sf "$WORKDIR/menu" /usr/local/bin/menu
sudo chmod +x /usr/local/bin/menu

echo "[+] Actualización completada."