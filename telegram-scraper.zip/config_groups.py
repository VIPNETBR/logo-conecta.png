import json
import os

GROUPS_FILE = "groups.json"

def configure_groups():
    groups = {}
    if os.path.exists(GROUPS_FILE):
        with open(GROUPS_FILE, 'r') as f:
            groups = json.load(f)

    origin = input(f"Ingrese el usuario público o link del grupo origen [{groups.get('origin', '')}]: ").strip()
    destination = input(f"Ingrese el usuario público o link del grupo destino [{groups.get('destination', '')}]: ").strip()

    if origin:
        groups['origin'] = origin
    if destination:
        groups['destination'] = destination

    with open(GROUPS_FILE, 'w') as f:
        json.dump(groups, f, indent=2)

    print("Grupos configurados correctamente.")

if __name__ == "__main__":
    configure_groups()