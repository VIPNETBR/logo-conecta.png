def configurar_grupos():
    with open("config/groups.conf", "w") as f:
        grupo_origen = input("Ingresa el grupo origen (nombre o link): ").strip()
        grupo_destino = input("Ingresa el grupo destino (nombre o link): ").strip()
        f.write(f"grupo_origen={grupo_origen}\n")
        f.write(f"grupo_destino={grupo_destino}\n")
    print("Grupos guardados exitosamente.")

if __name__ == "__main__":
    configurar_grupos()