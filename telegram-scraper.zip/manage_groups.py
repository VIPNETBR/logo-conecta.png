import yaml
import os

CONFIG_FILE = "config.yaml"

def cargar_config():
    if os.path.exists(CONFIG_FILE):
        with open(CONFIG_FILE, "r") as f:
            return yaml.safe_load(f) or {}
    return {}

def guardar_config(config):
    with open(CONFIG_FILE, "w") as f:
        yaml.dump(config, f)

def agregar_grupo():
    config = cargar_config()
    origenes = config.get("origenes", [])
    destino = config.get("destino", "")

    while True:
        grupo = input("🌐 Ingresa el grupo origen público (ej: @grupo): ").strip()
        if grupo.startswith("@"):
            origenes.append(grupo)
        else:
            print("❌ El grupo debe comenzar con @")
            continue
        agregar_otro = input("¿Deseas agregar otro grupo origen? (s/n): ").lower()
        if agregar_otro != "s":
            break

    dest = input("🌟 Ingresa el grupo destino (ej: @grupoDestino): ").strip()
    if dest.startswith("@"):
        destino = dest
    else:
        print("❌ El grupo debe comenzar con @")

    config["origenes"] = origenes
    config["destino"] = destino
    guardar_config(config)
    print("✅ Grupos guardados correctamente.")
