import yaml
import os

CONFIG_FILE = "config.yaml"

def cargar_config():
    if os.path.exists(CONFIG_FILE):
        with open(CONFIG_FILE, "r") as f:
            return yaml.safe_load(f) or {}
    return {}

def guardar_config(config):
    with open(CONFIG_FILE, "w") as f:
        yaml.dump(config, f)

def configurar_grupos():
    config = cargar_config()
    origenes = config.get("origenes", [])
    while True:
        grupo = input("🌐 Ingresa grupo origen público (ej: @grupo): ").strip()
        if grupo.startswith("@"):
            if grupo not in origenes:
                origenes.append(grupo)
            else:
                print("Grupo ya agregado.")
        else:
            print("Debe empezar con @")
            continue
        mas = input("¿Agregar otro grupo origen? (s/n): ").strip().lower()
        if mas != "s":
            break
    destino = input("🌟 Ingresa grupo destino (donde cargar miembros) (ej: @grupoDestino): ").strip()
    if not destino.startswith("@"):
        print("Debe empezar con @")
        destino = ""
    config["origenes"] = origenes
    config["destino"] = destino
    guardar_config(config)
    print("✅ Grupos configurados correctamente.")