import yaml

def configurar_grupos():
    with open("config.yaml", "r") as f:
        config = yaml.safe_load(f)

    origen = []
    while True:
        grupo = input("🔗 Ingrese el @grupo público origen (o Enter para terminar): ")
        if not grupo:
            break
        origen.append(grupo)

    destino = input("🎯 Ingrese el @grupo destino: ")

    config['origen'] = origen
    config['destino'] = destino

    with open("config.yaml", "w") as f:
        yaml.dump(config, f)

    input("✅ Grupos configurados correctamente. Presione Enter para continuar...")
