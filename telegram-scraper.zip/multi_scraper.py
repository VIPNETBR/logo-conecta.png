import yaml
from telethon.sync import TelegramClient
from telethon.sessions import StringSession

def cargar_cuentas():
    with open("cuentas.yaml", "r") as f:
        return [line.strip() for line in f if line.strip()]

def cargar_config():
    with open("config.yaml", "r") as f:
        return yaml.safe_load(f)

def main():
    cuentas = cargar_cuentas()
    config = cargar_config()
    for sesion in cuentas:
        try:
            with TelegramClient(StringSession(sesion), api_id=14867530, api_hash="45be4550cf972bfc274541b00fdf76a1") as client:
                participantes = client.get_participants(config['origen'])
                for usuario in participantes:
                    try:
                        client(InviteToChannelRequest(config['destino'], [usuario.id]))
                    except Exception:
                        pass
        except Exception:
            continue

if __name__ == "__main__":
    main()
