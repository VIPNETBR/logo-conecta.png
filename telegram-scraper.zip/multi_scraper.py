import asyncio, yaml, time
from telethon.sync import TelegramClient
from telethon.tl.functions.channels import GetParticipantsRequest, InviteToChannelRequest
from telethon.tl.types import ChannelParticipantsSearch

with open("cuentas.yaml", "r") as f:
    cuentas = yaml.safe_load(f)["cuentas"]
with open("grupos.yaml", "r") as f:
    grupos = yaml.safe_load(f)

usuarios = []

async def extraer_usuarios(client, link):
    global usuarios
    origen = await client.get_entity(link)
    offset = 0
    limit = 100
    while True:
        result = await client(GetParticipantsRequest(origen, ChannelParticipantsSearch(''), offset, limit, hash=0))
        if not result.users:
            break
        usuarios.extend(result.users)
        offset += len(result.users)
    print(f"✅ {len(usuarios)} usuarios extraídos de {link}")

async def agregar_usuarios(client, cuenta_id, destino_link):
    destino = await client.get_entity(destino_link)
    for user in usuarios:
        try:
            print(f"[{cuenta_id}] ➕ {user.id}")
            await client(InviteToChannelRequest(destino, [user.id]))
            time.sleep(15)
        except Exception as e:
            print(f"[{cuenta_id}] ❌ Error: {e}")
            time.sleep(5)

async def main():
    print("🔐 Usando la cuenta 1 para escaneo")
    client0 = TelegramClient('session_0', cuentas[0]['api_id'], cuentas[0]['api_hash'])
    await client0.start(cuentas[0]['phone'])
    for link in grupos['origen']:
        await extraer_usuarios(client0, link)
    await client0.disconnect()

    print("🚀 Rotando cuentas para agregar...")
    for i, cuenta in enumerate(cuentas):
        client = TelegramClient(f'session_{i}', cuenta['api_id'], cuenta['api_hash'])
        await client.start(cuenta['phone'])
        await agregar_usuarios(client, i+1, grupos['destino'])
        await client.disconnect()
        print(f"✅ Cuenta {i+1} completó su ronda.\n")
        time.sleep(10)

asyncio.run(main())
