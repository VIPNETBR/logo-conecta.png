from telethon.sync import TelegramClient
from telethon.sessions import StringSession
from telethon.tl.functions.messages import ImportChatInviteRequest
from telethon.tl.functions.channels import InviteToChannelRequest
import yaml

def ejecutar_scraper():
    with open("config.yaml", "r") as f:
        config = yaml.safe_load(f)

    with open("cuentas.yaml", "r") as f:
        sesiones = f.read().splitlines()

    origenes = config.get("origenes", [])
    destino = config.get("destino")

    if not origenes or not destino:
        print("❌ Configura los grupos antes de ejecutar.")
        return

    for sesion in sesiones:
        try:
            client = TelegramClient(StringSession(sesion), 14867530, "45be4550cf972bfc274541b00fdf76a1")
            client.connect()
            for grupo in origenes:
                miembros = client.get_participants(grupo)
                for miembro in miembros:
                    try:
                        client(InviteToChannelRequest(destino, [miembro]))
                    except Exception:
                        continue
            client.disconnect()
        except Exception as e:
            print(f"⚠️ Error con una cuenta: {e}")
