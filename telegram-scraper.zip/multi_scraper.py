import yaml
from telethon.sync import TelegramClient
from telethon.errors import FloodWaitError
from telethon.tl.functions.channels import GetParticipantsRequest
from telethon.tl.types import ChannelParticipantsSearch
import time

API_ID = 14867530
API_HASH = "45be4550cf972bfc274541b00fdf76a1"
CUENTAS_FILE = "cuentas.yaml"
CONFIG_FILE = "config.yaml"

def cargar_cuentas():
    with open(CUENTAS_FILE, "r") as f:
        return [line.strip() for line in f if line.strip()]

def cargar_config():
    with open(CONFIG_FILE, "r") as f:
        return yaml.safe_load(f) or {}

def ejecutar_scraper():
    cuentas = cargar_cuentas()
    config = cargar_config()
    origenes = config.get("origenes", [])
    destino = config.get("destino", None)
    if not destino or not origenes:
        print("Configura grupos origen y destino primero.")
        return
    print(f"Empezando scraping de {len(cuentas)} cuentas...")
    for session_str in cuentas:
        with TelegramClient(StringSession(session_str), API_ID, API_HASH) as client:
            for grupo in origenes:
                try:
                    print(f"Extrayendo miembros de {grupo}...")
                    offset = 0
                    limit = 100
                    all_participants = []
                    while True:
                        participants = client(GetParticipantsRequest(
                            grupo,
                            ChannelParticipantsSearch(''),
                            offset,
                            limit,
                            hash=0
                        ))
                        if not participants.users:
                            break
                        all_participants.extend(participants.users)
                        offset += len(participants.users)
                    print(f"Total miembros encontrados: {len(all_participants)}")
                    # Aquí se puede agregar código para agregar usuarios al grupo destino
                    # Por ahora solo mostramos total.
                except FloodWaitError as e:
                    print(f"Flood wait: espera {e.seconds} segundos.")
                    time.sleep(e.seconds)
                except Exception as e:
                    print(f"Error con grupo {grupo}: {e}")
    print("Scraping terminado.")