def run_scraper():
    print("Ejecutando scraper manual...")
    # Aquí va la lógica para extraer y agregar usuarios
    # Por ahora solo simula la ejecución
    print("Scraper ejecutado con éxito.")