import configparser

def ejecutar_scraper():
    config = configparser.ConfigParser()
    config.read("config/groups.conf")
    grupo_origen = config.get("DEFAULT", "grupo_origen", fallback=None)
    grupo_destino = config.get("DEFAULT", "grupo_destino", fallback=None)
    if not grupo_origen or not grupo_destino:
        print("Configura primero los grupos en la opción 2.")
        return

    print(f"Ejecutando scraper de {grupo_origen} a {grupo_destino} ...")
    # Aquí pondrías el código que hace el scraping y añade miembros
    # Por ejemplo: llamar a una función scrape_and_add(grupo_origen, grupo_destino)

if __name__ == "__main__":
    ejecutar_scraper()