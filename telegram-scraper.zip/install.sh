#!/bin/bash
echo "🔧 Instalando dependencias..."
apt update -y && apt upgrade -y
apt install -y python3 python3-pip python3-venv git unzip nano
cd $(dirname "$0")
echo "📦 Configurando entorno virtual..."
python3 -m venv venv
source venv/bin/activate
pip install --upgrade pip
pip install telethon pyyaml
echo "✅ Dependencias instaladas."
chmod +x menu.py
ln -sf $(pwd)/menu.py /usr/local/bin/menu
echo "✅ Instalación completa. Usa el comando 'menu' para comenzar."
