#!/bin/bash
echo "📦 Instalando dependencias..."
apt update && apt upgrade -y
apt install python3 python3-pip nano -y
pip3 install telethon pyyaml

chmod +x menu cron_launcher.sh
echo "✅ Instalación completada. Ejecuta 'bash menu' para comenzar."
