#!/bin/bash
echo "📦 Instalando dependencias..."
apt update -y && apt upgrade -y
apt install -y python3 python3-pip git unzip cron nano
pip3 install --upgrade pip
pip3 install telethon pyyaml
chmod +x menu
ln -sf $(pwd)/menu /usr/local/bin/menu
(crontab -l ; echo "0 3 * * * cd $(pwd) && python3 multi_scraper.py >> scraper.log 2>&1") | crontab -
echo "✅ Instalación completada. Escribe 'menu' para comenzar."
